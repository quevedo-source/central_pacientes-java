/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.central_pacientes;

/**
 *
 * @author Juan Diego Quevedo
 */
public class ListaPacientes {
    private Nodo cabeza;

    public ListaPacientes() {
        this.cabeza = null;
    }

    public void agregarPaciente(Paciente paciente){
        Nodo nuevo = new Nodo(paciente);
        if(cabeza == null){
            cabeza = nuevo;
        }
        else{
            Nodo temp = cabeza;
            while(temp.siguiente != null){
                temp = temp.siguiente;
            }
            temp.siguiente = nuevo;
        }
        System.out.println("Paciente agregado con exito.");
    }

    public Paciente buscarPaciente(int id){
        Nodo temp = cabeza;
        while(temp != null){
            if(temp.paciente.id == id){
                return temp.paciente;
            }
            temp = temp.siguiente;
        }
        return null;
    }

    public boolean eliminarPaciente(int id){
        if(cabeza == null){
            return false;
        }
        if(cabeza.paciente.id == id){
            cabeza = cabeza.siguiente;
            return true;
        }
        Nodo temp = cabeza;
        while(temp.siguiente != null && temp.siguiente.paciente.id != id){
            temp = temp.siguiente;
        }
        if(temp.siguiente == null){
            return false;
        }
        temp.siguiente = temp.siguiente.siguiente;
        return true;
    }

    public void mostrarPacientes(){
        if(cabeza == null){
            System.out.println("No hay pacientes registrados.");
            return;
        }
        Nodo temp = cabeza;
        while(temp != null){
            System.out.println(temp.paciente);
            temp = temp.siguiente;
        }
    }
}
