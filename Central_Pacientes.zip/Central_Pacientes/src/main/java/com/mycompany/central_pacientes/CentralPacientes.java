/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.central_pacientes;

/**
 *
 * @author Juan Diego Quevedo
 */
public class CentralPacientes {

    public static void main(String[] args) {
        ListaPacientes lista = new ListaPacientes();

        lista.agregarPaciente(new Paciente(1, "Juan Perez", 30, "Clinica Norte"));
        lista.agregarPaciente(new Paciente(2, "Maria Gomez", 25, "Clinica Sur"));
        lista.agregarPaciente(new Paciente(3, "Carlos Ruiz", 40, "Clinica Central"));

        System.out.println("\nLista de pacientes:");
        lista.mostrarPacientes();

        System.out.println("\nBuscando paciente con ID 2:");
        Paciente encontrado = lista.buscarPaciente(2);
        if(encontrado != null){
            System.out.println("Paciente encontrado: " + encontrado);
        } else {
            System.out.println("Paciente no encontrado.");
        }

        System.out.println("\nEliminando paciente con ID 1:");
        boolean eliminado = lista.eliminarPaciente(1);
        if(eliminado){
            System.out.println("Paciente eliminado con exito.");
        } else {
            System.out.println("Paciente no encontrado para eliminar.");
        }

        System.out.println("\nLista de pacientes actualizada:");
        lista.mostrarPacientes();
    }
}
